Author: Ameerah Allie
Date: 18 May 2014
Assignment 6

Description: Processed MYSQL queries to asnwer "management" questions

Sources: "ALLAME002 Asssignment6.txt", "matricData.csv", "uniData.csv"

Instructions:
1. Read "ALLAME002 Assignment6.txt" for answers to questions

Note: I appended all input and output to the text file with the MYSQL commands "TEE 'ALLAME002 Assignment6.txt'" which opens the connection to the file and appends all input and output and "NOTEE" which closes the connection.
